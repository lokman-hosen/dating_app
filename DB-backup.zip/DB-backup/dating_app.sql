-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 06, 2020 at 06:05 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dating_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `owner_id` int(10) UNSIGNED NOT NULL,
  `follower_id` int(10) UNSIGNED NOT NULL,
  `like_status` tinyint(4) NOT NULL COMMENT '0 for dislike and 1 for like',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `owner_id`, `follower_id`, `like_status`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 0, NULL, '2020-09-05 10:08:21'),
(2, 3, 1, 0, NULL, '2020-09-05 05:29:28'),
(3, 3, 1, 0, NULL, '2020-09-05 05:29:28'),
(4, 1, 3, 1, NULL, NULL),
(5, 1, 4, 1, NULL, '2020-09-05 07:00:23'),
(6, 4, 1, 1, '2020-09-05 03:50:29', '2020-09-05 04:33:35'),
(7, 4, 3, 1, '2020-09-05 05:02:27', '2020-09-05 11:12:05'),
(11, 1, 2, 1, '2020-09-05 06:50:14', '2020-09-05 07:09:43'),
(12, 3, 2, 1, '2020-09-05 07:09:54', '2020-09-05 07:09:54'),
(13, 3, 6, 1, '2020-09-05 11:09:41', '2020-09-05 11:10:12'),
(14, 1, 6, 1, '2020-09-05 11:10:29', '2020-09-05 11:10:29'),
(15, 6, 3, 0, '2020-09-05 11:11:50', '2020-09-05 11:18:39'),
(16, 9, 1, 1, '2020-09-06 07:48:44', '2020-09-06 07:48:44'),
(17, 1, 9, 1, '2020-09-06 07:55:38', '2020-09-06 07:55:38'),
(18, 11, 6, 1, '2020-09-06 09:05:09', '2020-09-06 09:07:21'),
(19, 6, 11, 1, '2020-09-06 09:06:45', '2020-09-06 09:06:45');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_09_05_064248_create_likes_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` tinyint(4) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `location_latitude` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_longitude` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `gender`, `birth_date`, `location_latitude`, `location_longitude`, `user_image`, `email_verified_at`, `password`, `status`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Lokman Hosen', 'lokman.cse.pstu@gmail.com', 1, '1994-02-01', '22.7267037', '90.3653193', 'lokman-hosen_2020-09-05_5f53be77575f4.png', NULL, '$2y$10$VPR2jOOmnhcEvxayuVEf6.NbCdqvc6zzaDwQE8wyrFkfQvsV95V0i', 1, NULL, '2020-09-04 09:11:20', '2020-09-05 10:36:07', NULL),
(2, 'Enamul Hashan', 'enamul@gmail.com', 1, '2020-09-01', '24.7105776', '88.94138650000001', '2020-09-04_5f525990d8b7a.png', NULL, '$2y$10$YxVhSFJYrj9jDfOmyq0T4uYxyJ19NyjWn0DMRfa06DTNT54woxcbS', 1, NULL, '2020-09-04 09:13:21', '2020-09-04 09:13:21', NULL),
(3, 'Khadiza Khanam', 'khadiza494@gmail.com', 2, '1994-12-31', '22.713103', ' 90.356779', 'khadiza-khanam_2020-09-05_5f53be994364d.jpg', NULL, '$2y$10$HAFT13WrPacEgqjh/eTJ9.Rdb/kN7XH92SJGsj8Lk6KI7Vd3MZEhy', 1, NULL, '2020-09-05 02:13:58', '2020-09-05 10:36:41', NULL),
(4, 'Musfiqur Rahman', 'musfiq@gmail.com', 1, '1994-09-05', '24.7105776', '88.94138650000001', 'musfiqur-rahman_2020-09-05_5f53beb484eb1.jpg', NULL, '$2y$10$MLbMcP0//Hz0.37IAwdnde8dlF/00BEIOlSgv4t62yTBQ6RzyFF72', 1, NULL, '2020-09-05 03:05:11', '2020-09-05 10:37:08', NULL),
(5, 'Jishan Mahmud', 'jishan@gmail.com', 1, '1993-09-05', '22.7267037', '90.3653193', 'jishan-mahmud_2020-09-05_5f53c4fad143b.jpg', NULL, '$2y$10$jumDNZeVM/cqN/SlWWGOIehD6LmkXwBvHuO/SSiytHaBIGd12Kxyi', 1, NULL, '2020-09-05 11:03:26', '2020-09-05 11:03:54', NULL),
(6, 'Hasinul Islam', 'hasinul@gmail.com', 1, '1994-09-05', '22.7265576', '90.3529195', 'hasinul-islam_2020-09-05_5f53c6ff08b5a.jpg', NULL, '$2y$10$4GJBPs02.Pdt/A9o3HGdQe8JADYcE6sKW6gkRfoHZsjSlIk/IX4ku', 1, NULL, '2020-09-05 11:07:08', '2020-09-05 11:12:31', NULL),
(7, 'Afik Hasan', 'atik@gmail.com', 1, '2020-09-06', '23.807140', '90.368714', 'afik-hasan_2020-09-06_5f54ce740e551.jpg', NULL, '$2y$10$Ep5okBI2BfNIvwdDezVcI.SVgGv4E6M10lOZXMfJOLIXhQILyUDz.', 1, NULL, '2020-09-05 13:00:11', '2020-09-06 05:56:36', NULL),
(9, 'Kawser', 'kawser@gmail.com', 1, '1993-09-06', '22.727231', '90.359532', 'kawser_2020-09-06_5f54dcc90fb26.png', NULL, '$2y$10$ZJiWX4yVKV4vU6rAzcHRh.F539elDRJpkGId5r4J2XMvpk700S2cG', 1, NULL, '2020-09-06 06:48:51', '2020-09-06 06:57:45', NULL),
(10, 'Jobaydul Hashan', 'jobaydul@gmail.com', 1, '2000-09-06', '22.7267037', '90.3653193', 'jobaydul-hashan_2020-09-06_5f54f63a6b9fb.jpg', NULL, '$2y$10$d3QenCVGO39nNRaTYniG0.qbP1U4cy2k6tqdzzkZPFJEE9SKjR6e2', 1, NULL, '2020-09-06 08:44:39', '2020-09-06 08:46:18', NULL),
(11, 'Tapos Karmoker', 'tapos@gmail.com', 1, '1995-09-01', '22.7267037', '90.3653193', 'tapos-karmoker_2020-09-06_5f54f8a7578b5.png', NULL, '$2y$10$MuoZrgfP.ZGjohCDllcsSO/xtS52mN8ZCWeRdSjuK49YD9l/GEGxW', 1, NULL, '2020-09-06 08:50:27', '2020-09-06 08:56:39', NULL),
(12, 'Jobayer Ahmed', 'jobayer@gmail.com', 1, '1980-09-06', '22.7267037', '90.3653193', 'jobayer-ahmed_2020-09-06_5f5500147eff0.jpg', NULL, '$2y$10$Oa2K3W3MJ1secPyUxqGApOSt9vxNrvXVjst57P/gEZGcsDIgz3.72', 1, NULL, '2020-09-06 09:28:20', '2020-09-06 09:28:20', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
